package fraction;

public interface FractionOperations {
    double getDecimalValue();
}