package animals;
public interface Meowable {
    void meow();
    void meow(int n);
}